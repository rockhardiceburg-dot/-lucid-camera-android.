# Lucid Camera — Android starter project

Package: `com.lucid.camera`  
Version: `1.0.0` (versionCode 1)  
Initial target: Samsung Galaxy A15 5G / Android 15

This is a runnable **starter app**, not the finished live-camera pipeline described by the original F-Droid metadata. It is a native Android Activity wrapping a local HTML interface in a WebView. It can open a still image, apply browser-based effects, and export a processed copy.

## Build using Android Studio

1. Install Android Studio on a computer and install Android SDK Platform 35 and a Java 17-compatible toolchain.
2. Extract this archive.
3. In Android Studio, choose **Open** and select the extracted `LucidCameraAndroid` folder.
4. Allow Gradle sync to complete. The first sync needs internet access to download the Android Gradle Plugin and Kotlin plugin.
5. Connect the Galaxy A15 with USB debugging enabled, or use an emulator.
6. Choose **Run** to install the debug build.

To create an APK, choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.

This archive intentionally does not include a Gradle wrapper JAR or a prebuilt APK. Android Studio can import the project and provision the build environment; a successful APK build has not been verified in this environment.

## What's included

- Native Android launcher activity
- Local-only WebView entry point at `app/src/main/assets/index.html`
- Image picker support through WebView's file chooser
- Natural, monochrome, warm, cool, dream, and vivid still-image effects
- No network permission or third-party runtime libraries
- Gradle Kotlin DSL project files

## Current limitations

- Effects operate on selected still images, not continuous camera frames.
- This prototype does not replace Android's system camera and cannot force Discord to use its output.
- It has no camera streaming service, virtual camera driver, or Discord integration.
- Export is browser-based; behavior can vary by Android WebView version.
- The app has not yet been built, installed, or tested on the target phone.

## GitHub publishing

Create a **new empty public repository** on GitHub, then from this extracted folder run:

```bash
git init
git add .
git commit -m "Initial Lucid Camera Android prototype"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/grok-workspace-a146u.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username and use the exact repository URL GitHub gives you. If Git asks you to authenticate, use GitHub's supported sign-in or token flow; do not put a password in the remote URL.

## F-Droid note

`com.lucid.camera.yml` is included as the supplied submission metadata, but it references a separate repository and build process that are not present yet. Do not submit it as-is. Update its `Repo`, `SourceCode`, build steps, and release tag after the public repository has been created and the project builds reproducibly. A Git URL is not an F-Droid app-repository URL.
